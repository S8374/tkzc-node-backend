/* eslint-disable @typescript-eslint/no-non-null-assertion */
import dotenv from "dotenv";

dotenv.config()

interface EnvConfig {
  PORT: string;
  DB_URL: string;
  NODE_ENV: "development" | "production";
  BCRYPT_SALT_ROUND: string;

  JWT_ACCESS_SECRET: string;
  JWT_ACCESS_EXPIRES: string;
  JWT_REFRESH_SECRET: string;
  JWT_REFRESH_EXPIRES: string;

  SUPER_ADMIN_EMAIL: string;
  SUPER_ADMIN_PASSWORD: string;

  EXPRESS_SESSION_SECRET: string;
  FRONTEND_URL: string;
EMAIL_SENDER: {
  SMTP_HOST: string,
  SMTP_PORT: string,
  SMTP_USER: string,
  SMTP_PASS: string,
  SMTP_FROM: string,
},
 
}


const loadEnvVariables = (): EnvConfig => {
    const requiredEnvVariables: string[] = ["PORT", "DB_URL", "NODE_ENV", "BCRYPT_SALT_ROUND", "JWT_ACCESS_EXPIRES", "JWT_ACCESS_SECRET", "SUPER_ADMIN_EMAIL", "SUPER_ADMIN_PASSWORD", "JWT_REFRESH_SECRET", "JWT_REFRESH_EXPIRES",  "FRONTEND_URL", "EXPRESS_SESSION_SECRET", "EMAIL_SENDER_SMTP_HOST", "EMAIL_SENDER_SMTP_PORT", "EMAIL_SENDER_SMTP_USER", "EMAIL_SENDER_SMTP_PASS", "EMAIL_SENDER_SMTP_FROM"];

    requiredEnvVariables.forEach(key => {
        if (!process.env[key]) {
            throw new Error(`Missing require environment variabl ${key}`)
        }
    })

 return {
  PORT: process.env.PORT as string,
  DB_URL: process.env.DB_URL!,
  NODE_ENV: process.env.NODE_ENV as "development" | "production",
  BCRYPT_SALT_ROUND: process.env.BCRYPT_SALT_ROUND as string,

  JWT_ACCESS_SECRET: process.env.JWT_ACCESS_SECRET as string,
  JWT_ACCESS_EXPIRES: process.env.JWT_ACCESS_EXPIRES as string,
  JWT_REFRESH_SECRET: process.env.JWT_REFRESH_SECRET as string,
  JWT_REFRESH_EXPIRES: process.env.JWT_REFRESH_EXPIRES as string,

  SUPER_ADMIN_EMAIL: process.env.SUPER_ADMIN_EMAIL as string,
  SUPER_ADMIN_PASSWORD: process.env.SUPER_ADMIN_PASSWORD as string,

  EXPRESS_SESSION_SECRET: process.env.EXPRESS_SESSION_SECRET as string,
  FRONTEND_URL: process.env.FRONTEND_URL as string,
    EMAIL_SENDER: {
    SMTP_HOST: process.env.EMAIL_SENDER_SMTP_HOST as string,
    SMTP_PORT: process.env.EMAIL_SENDER_SMTP_PORT as string,
    SMTP_USER: process.env.EMAIL_SENDER_SMTP_USER as string,
    SMTP_PASS: process.env.EMAIL_SENDER_SMTP_PASS as string,
    SMTP_FROM: process.env.EMAIL_SENDER_SMTP_FROM as string,
    }
};

}

export const envVars = loadEnvVariables()